<?php
session_start();
include 'include/dbconnect.php';
include 'function.php';


if(isset($_POST['login']) && $_POST['login']=='login'){


$data= array();
$data['email']= sanitizeString($_POST['email']);
$data['password']= sanitizeString($_POST['psw']);

if(empty($data['email'])){
	$_SESSION['error']="email must not be empty";
	header('location: login.php');

}elseif(empty($data['password'])){

	$_SESSION['error']="password must not be empty";
	header('location: login.php');
}else{
	$result = loginfun($data);

if($_COOKIE['email']>=3)
		{
		$_SESSION['error']="Blocked for 3 min";
		header('location: login.php');
		}
	else 
	{
		if($result){
		
		$_SESSION['email']= $data['email'];
		$_SESSION['success']= "welcome"." ".$data['email'];
		header('location: book.php');
		
		}
		else
		{
	
		setcookie("email",1,time()+180);
		
			if(isset($_COOKIE['email'])){
					setcookie("email",$_COOKIE['email']+1,time()+180);
					$_SESSION['error']="Wrong attempt!! 1 attempt left";
					header('location: login.php');
							
			}
			
			else{
				
				$_SESSION['error']="Wrong attempt!! 2 attempt left";
				header('location: login.php');
			}
		}

	}

  }

}


else{
	$_SESSION['error']="invalid access!!";
	header('location: index.php');
}



?>