<?php 


function sanitizeString($data){
	global $conn;
	return mysqli_real_escape_string($conn,$data);

}


function bikeinfo (){
				global $conn;
	$sql= "select * from  bike_information order by bike_id desc";
	$query=mysqli_query($conn,$sql);

	$count=mysqli_num_rows($query);

	if($count!=0){
		$data=array();
		while($row=mysqli_fetch_assoc($query)){
			$data[]=$row;

		}
		return $data;
		
	
	}else{
		return false;
	}

}


function register ($data){
	global $conn;
	$sql = " insert into user
			 set
			 firstname = '".$data['firstname']."',
			 lastname = '".$data['lastname']."',
			 email = '".$data['email']."',
			 password = '".$data['password']."'
			  
			  ";
	
	$query = mysqli_query($conn,$sql);
		if($query){
		return true;
	}else{
		return false;
	}
}

function check($data)
{
	global $conn;
	$sql = "select email from user where email='".$data['email']."' 
				 ";	


				 $query=mysqli_query($conn,$sql);


	$count=mysqli_num_rows($query);

	if($count>0){
		return true;
	}
	else{
		return false;
	}

}



function loginfun($data){
					global $conn;
		$sql = "select * from user
          where email='".$data['email']."' 
				and password='".$data['password']."' ";
		
		$query = mysqli_query($conn,$sql);
		$count = mysqli_num_rows($query);
		if($count){
		return true;
		
		}else{
		return false; 
	}

}


function bookprocess($data){

						global $conn;
	$sql = " insert into book
			 set
			
			 email = '".$data['email']."',
			 bike_name= '".$data['name']."',
			 bike_number= '".$data['number']."',
			 date= '".$data['date']."',
			 days= '".$data['day']."'
			  ";

			  
			  	$query = mysqli_query($conn,$sql);
	if($query){
		return true;
	}else{
		return false;
	}
}

function vbook($email){

		global $conn;
		$sql = "select * from  book where email='".$email."' 
				 ";
		
		$query = mysqli_query($conn,$sql);
		$count = mysqli_num_rows($query);
		
		if($count!=0){
		$data=array();
		while($row=mysqli_fetch_assoc($query)){
			$data[]=$row;

		}
		return $data;
		
	
	}else{
		return false;
	}
}

function bookingDelete($id){

	
	global $conn;
	$sql="delete from book where book_id=$id";

	
	$query=mysqli_query($conn,$sql);
	if($query){
		return true;
	}else{
		return false;
	}
}


 ?>