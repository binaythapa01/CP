<?php

 require ('function.php');

use PHPUnit\Framework\TestCase;

class FirstTest extends TestCase
{
   
    public function testregister(){

        
 
        
        
        // $function = new function();
        
        //  $function ->setfirstname("abc");
        //  $this->assertEquals($function -> getfirstname(), 'abc');
    }
    // public function test_namesetter(){
    //     $user = new user();
    //     $user -> setEmail("khatrisantos3@gmail.com");
    //     $this -> assertEquals($user -> getEmail(), "khatrisantos3@gmail.com");
    // }
}

?>