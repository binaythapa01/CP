<?php

require ("classes/user.php"); 

use PHPUnit\Framework\TestCase;


class SecondTest extends testcase {

    public function test_namesettergetter(){
        $user = new user();
        $user ->setFirstname("santosh");
        $this->assertEquals($user->getFirstname(), "santosh");
    } 
}

?>