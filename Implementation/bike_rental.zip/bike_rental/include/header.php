


<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  
    <script src="js/jquery-3.3.1.min.js"></script> 
	<script src="js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<title>User dashbord</title>
</head>
<body>
	<div class="container-flude">
			<div class="row">
				<div class="col-lg-12 bg-primary">
					<h1>DASHBOARD-USER</h1>
					<a href="logout.php" id="logout.php" class="btn btn-danger">
					<i class="fa fa-fw fa-power-off"></i> Log Out</a>
					<a href="index.php" class="btn btn-primary">Home</a>
				</div>
			</div>
		</div> 

		
				<nav class="navbar navbar-expand bg-dark" id="nav">
			<div class="container-fluid">

				<ul class="navbar-nav">
					<li class="nav-item"><a href="updateprofile.php" data-target="student" 
					class="nav-link text-white" ><span class="fa fa-fw fa-plus"></span>update-profile</a></li>
					<li class="nav-item"><a href="viewbook.php" data-target="profile" class="nav-link">
					<span class="fa fa-fw fa-list"></span>VIEW-BOOKING</a></li>
					<li class="nav-item"><a href="book.php" data-target="profile" class="nav-link">
					<span class="fa fa-fw fa-plus"></span>ADD-BOOKING</a></li>

					
					<!-- <li class="nav-item"><a href="vbooking.php" data-target="booking" 
					class="nav-link"><i><span class="fa fa-fw fa-list"></span>VIEW-BOOKING</i></a></li> -->

				</ul>

			</div>
		</nav>



		<div class="container">
			<div class="row">
				<div class="col-lg-8"  id="section">
				
				<?php
				include 'include/notification.php';
				
				?>
</div>
</div>
</div>
</body>
</html>

		


