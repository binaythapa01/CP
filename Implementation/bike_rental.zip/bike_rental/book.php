<?php 

session_start();


if(empty($_SESSION['email'])){
	$_SESSION['error']="Access Denied!!";
	header('location: login.php');
	exit;
}
include 'include/dbconnect.php';
include 'include/header.php';
include 'function.php';
?>




<div class="container">
			<div class="row">
				<div class="col-lg-12">

          <fieldset> 
					<legend>Booked Bike</legend>
			<form method="post" action="booking-process.php" enctype="multipart/form-data">
				
				
				<?php
					include 'include/notification.php';
				
				?>
				<div class="form-group">
					<label>Bike Name</label>
					<input type="text" name="name" class="form-control" required="" placeholder="Enter name">
				</div>

                     <div class="form-group">
					<label>Bike Number</label>
					<input type="text" name="number" class="form-control" required="" placeholder="Enter number">
				</div>

				<div class="form-group">
					<label>DATE</label>
					<input type="text-area" name="date" class="form-control" required=""
					placeholder="Enter date for rent">
				</div>

				<div class="form-group">
					<label>DAYS</label>
					<input type="text-area" name="day" class="form-control" required=""
					placeholder="Enter for how many days to needed">
				</div>

           <input type="submit" name="book" class="btn btn-success btn-block" value="book">
				
			</form>
			</fieldset>





 </div>
</div>
</div>