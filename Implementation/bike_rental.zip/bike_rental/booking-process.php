<?php 
	session_start();
	include 'include/dbconnect.php';
	include 'function.php';

 ?>


<?php 



 if(empty($_SESSION['email'])){
 	$_SESSION['error']="Access Denied!!";
 	header('location: login.php');
}

	 if(isset($_GET['id']) && $_GET['act']=="delete"){
	 	$id=$_GET['id'];

	 	
	 	$result = bookingDelete($id);
		
	 	if($result){
	 		$_SESSION['success']="File Deleted";
	 		header('location: viewbook.php');
	 	}
		
	 	else{
 		$_SESSION['error']="File Couldnot Deleted";
	 		header('location: viewbook.php');
	 	}
	}

if (isset($_POST['book'])&& $_POST['book']=='book') {

	$email=$_SESSION['email'];
	$data=array();
	$data['email']= sanitizeString($email);
	$data['name']= sanitizeString($_POST['name']);
	$data['number']= sanitizeString($_POST['number']);
	$data['date']= sanitizeString($_POST['date']);
	$data['day']= sanitizeString($_POST['day']);


  $result=bookprocess($data);
   if($result){
   	$_SESSION['email']= $data['email'];
		$_SESSION['success']= "welcome"." ".$data['email'];
		header('location: book.php');

   }

else{

	$_SESSION['error']="book is not done";
	header('location: book.php');	
		
}
}

 ?>