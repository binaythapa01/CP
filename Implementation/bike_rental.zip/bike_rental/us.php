   <!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  
    <script src="js/jquery-3.3.1.min.js"></script> 
  <script src="js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
  <link rel="stylesheet" type="text/css" href="assets/style.css">
  <title>BIKE RENTAL</title>
</head>
<body>

  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-4 logo">
        <img src="assets/images/logo.png" alt="logo of company" 
        style="height: 100px; width: 200px;">
      </div>      <div class="col-sm-6">
    
      </div>
    </div>
  </div>
  <div class="container-fluid p-0">
           <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">EVERST BIKE RENTAL</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" 
  data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
  aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="us.php">Contact Us</a>

      </li>

       <li class="nav-item">
        <a class="nav-link" href="viewbikeinfo.php">Bike infomation</a>

    

    </ul>
     
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>

</nav>



   <div class="container-fluid">
    <h2>Location</h2>

    <div class="row">
      <div class="col-lg-12 col-sm-12 col-md-12">

     <iframe class="location" 
	 src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14129.471317566644!2d85.3302047!3d27.7059272!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x74ebef82ad0e5c15!2z4KS44KSr4KWN4KSf4KS14KS-4KSw4KS_4KSV4KS-IOCkleCksuClh-CknCDgpIXgpKsg4KSG4KSH4KSf4KWAIOCkj-Cko-CljeCkoSDgpIgt4KSV4KSu4KSw4KWN4KS4!5e0!3m2!1sne!2snp!4v1555581867253!5m2!1sne!2snp" 
	 width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        
      </div>
    </div>
    </div>








    <footer>



  

<div class="card text-center">
  <div class="card-header" style="background-color:black;">
    
  </div>
  <div class="card-body" style="background-color:black;">
    <h5 class="card-title">&copy;EVEREST BIKE RENTAL </h5>
    <h6 class="card-title">Ouick links </h6>
     <a href="login.php" class="btn btn-primary">LOGIN</a>
    <a href="register.php" class="btn btn-primary">REGISTER</a>


      <div class="container-fluid top-bar" style="background-color:black;">
    <div class="col-sm-12">
      <div class="row">
        <div class="col-sm-8">

        <div class="col-sm-4 d-flex flex-row-reverse">
          <a href="https://www.facebook.com" class="social-icons"><i class="fab fa-facebook-square"></i></a>
          <a href="https://www.google.com" class="social-icons"><i class="fab fa-google-plus-g"></i></a>
          <a class="social-icons"  href="https://www.twitter.com">  <i  class="fab fa-twitter"></i></a>
          <a  href="https://www.youtube.com" class="social-icons"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>

</footer>

</body>
</html>