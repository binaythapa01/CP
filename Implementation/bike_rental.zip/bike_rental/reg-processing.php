<?php 
session_start();
include 'include/dbconnect.php';
include 'function.php';


if(isset($_POST['signin']) && $_POST['signin']=='signin'){




$data= array();
$data['firstname']= sanitizeString($_POST['firstname']);
$data['lastname']= sanitizeString($_POST['lastname']);
$data['email']= sanitizeString($_POST['email']);
$data['password']= sanitizeString($_POST['password']);




$da=check($data);


if($da){
	$_SESSION['error']="email has already resgister";
	header('location:register.php');
}

elseif(empty($data['firstname'])){
	$_SESSION['error']="firstname must not be empty";
	header('location: register.php');

}elseif(empty($data['lastname'])){
	$_SESSION['error']="lastname must not be empty";
	header('location: register.php');

}elseif(empty($data['email'])){
	$_SESSION['error']="email must not be empty";
	header('location: register.php');

}elseif(empty($data['password'])){

	$_SESSION['error']="password must not be empty";
	header('location: register.php');
}else{
	$result = register($data);

	if($result){

		
				
		$_SESSION['email']= $data['email'];
		$_SESSION['success']= "welcome"." ".$data['email'];
		header('location: index.php');
		

		
		
	}else{
		$_SESSION['error']="email/password invalid!!";
		header('location: register.php');
	}

}
}





 ?>