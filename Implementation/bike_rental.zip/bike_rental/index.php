<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  
    <script src="js/jquery-3.3.1.min.js"></script> 
	<script src="js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<title>BIKE RENTAL</title>
</head>
<body>

	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-4 logo">
				<img src="assets/images/logo.png" alt="logo of curious cybersecurity" 
				style="height: 100px; width: 200px;">
			</div>
			<div class="col-sm-6">
		
			</div>
		</div>
	</div>
  <div class="container-fluid p-0">
           <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">EVERST BIKE RENTAL</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" 
  data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
  aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="us.php">ABOUT US</a>

      </li>

       <li class="nav-item">
        <a class="nav-link" href="viewbikeinfo.php">Bike infomation</a>

    

    </ul>
 <!--     
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form> -->
    <a href="assets/images/help.pdf" class="btn btn-primary">HELP</a>


  </div>

  



</nav>
  </div>

  <h1 class="text-center bg-info">Introduction of company</h1>
<p class="text-center">  everst company is a bike renatal company founded in 2016, created by abc
 <br/>
             Their ambition is to renat bike
              </p> 


<div class="bd-example">
  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="assets/images/ns.jpg." class="d-block w-100" alt="..." style="height: 1024px;">
        <div class="carousel-caption d-none d-md-block">
          <h5>bike</h5>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="assets/images/bullet.jpg." class="d-block w-100" alt="..."  style="height: 1024px;">
        <div class="carousel-caption d-none d-md-block">
          <h5>view</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="assets/images/fz.jpg." class="d-block w-100" alt="..."  style="height: 1024px;">
        <div class="carousel-caption d-none d-md-block">
          <h5>ser</h5>
          <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>







<footer>



	

<div class="card text-center">
  <div class="card-header" style="background-color:black;">
    
  </div>
  <div class="card-body" style="background-color:black;">
    <h5 class="card-title">&copy;EVEREST BIKE RENTAL </h5>
    <h6 class="card-title"> </h6>
    <a href="login.php" class="btn btn-primary">LOGIN</a>
    <a href="register.php" class="btn btn-primary">REGISTER</a>
<!--        <a href="help" class="btn btn-primary">HELP</a>
 -->

      <div class="container-fluid top-bar" style="background-color:black;">
    <div class="col-sm-12">
      <div class="row">
        <div class="col-sm-8">

        <div class="col-sm-4 d-flex flex-row-reverse">
          <a href="https://www.facebook.com" class="social-icons"><i class="fab fa-facebook-square"></i></a>
          <a href="https://www.google.com" class="social-icons"><i class="fab fa-google-plus-g"></i></a>
          <a class="social-icons"  href="https://www.twitter.com">  <i  class="fab fa-twitter"></i></a>
          <a  href="https://www.youtube.com" class="social-icons"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>

</footer>

</body>
</html>