<!DOCTYPE html>
<html>
<head>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  
    <script src="js/jquery-3.3.1.min.js"></script> 
	<script src="js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<title>Contact Us</title>
</head>
<body>
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<fieldset>
						<legend>Contact Us</legend>
					<form method="Post" action="contact.php" class="form-horizontal">
						<div class="form-group">
							<label >Username</label>
							<input type="text" name="uname" class="form-control">
						</div>
						<div class="form-group">
							<label >Email</label>
							<input type="text" name="email" class="form-control">
						</div>
						<div class="form-group">
							<label >Phone</label>
							<input type="text" name="phone" class="form-control">
						</div>
						<div class="form-group">
							<label >Message</label>
							<textarea></textarea>
						</div>


						
							
							<input type="submit" name="submit" class="btn btn-success btn-block" value="submit">
					
					</form>
					</fieldset>
				</div>
			</div>
		</div>

</body>
</html>