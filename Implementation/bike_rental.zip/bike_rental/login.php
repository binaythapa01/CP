 <?php
session_start();

?>
<html>
	<head>
	<title>User login</title>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  
    <script src="js/jquery-3.3.1.min.js"></script> 
	<script src="js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link rel="stylesheet" type="text/css" href="assets/style.css">


	</head>
	
	
	<body>
	
		<div  class="container">
			<div class="row">
				<div class="col-lg-6">
				<?php
					include 'include/notification.php';
				?>
					<fieldset>
						<legend>USER LOGIN</legend>
						<form method="post" action="lo-process.php" class="form form-horizontal">
							<div class="form-group">
								<label>EMAIL</label>
								<input type="text" name="email" class="form-control">

							</div>
							
							<div class="form-group">
								<label>PASSWORD</label>
								<input type="password" name="psw" class="form-control">

							</div>
							
							<div class="form-group">
								<input type="checkbox" name="remember">
								<label>Remember-me</label>
							</div>
							
							<input type="submit" name="login" value="login" class="btn btn-success" >
												
						
						</form>
					
					</fieldset>
				
				</div>
			</div>
		
		</div>
		
	</body>

</html>