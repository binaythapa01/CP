<?php 
// session_start();
include 'include/dbconnect.php';
include 'include/header.php';
include 'function.php';


 ?>







		 <div class="container">
	<div class="row">
		<div class="col-sm-12 col-md-6 col-lg-6 offset-3">




			<?php 
					if(isset($_GET['bike_id']) && $_GET['act']=="edit")
					{
					$bike_id=$_GET['bike_id'];
					$result = updatebike($bike_id);

				/* 	 debugger($result);
					exit;  */
				?>
					<fieldset> 
					<legend>UPDATE-BIKE INFORMATION</legend>
				<form method="post" action="bikeinfo-process.php" enctype="multipart/form-data">
			
				
				<?php
					include 'include/notification.php';
				
				?>

				<div class="form-group">
					<label>BIKE NAME</label>
					<input type="text-area" name="name" class="form-control" required="" value=
					"<?php echo $result[0]['bike_name'] ?>">

					<div class="form-group">
					<label>BIKE NUMBER</label>
					<input type="text-area" name="number" class="form-control" required="" value=
					"<?php echo $result[0]['bike_number'] ?>">

				</div>
				<div class="form-group">
					<label>DESCRIPTION</label>
					<input type="text-area" name="description" class="form-control" required="" value=
					"<?php echo $result[0]['description'] ?>">
					

				</div>

					<div class="form-group">
					<label>PRICE</label>
					<input type="text-area" name="price" class="form-control" required="" value=
					"<?php echo $result[0]['price'] ?>">
					

				</div>

				

				<div class="form-group">
					<input type="file" name="image" required="">
				</div>
				
				<input type="text" name="bike_id" value="<?php echo $bike_id; ?>" hidden>
				<input type="submit" name="update" class="btn btn-success" value="update">
				
			</form>
			</fieldset>
			
			<?php
					}
					else{
				?>
			<fieldset> 
					<legend>ADD Bike Infomation</legend>
			<form method="post" action="bikeinfo-process.php" enctype="multipart/form-data">
				
				
				<?php
					include 'include/notification.php';
				
				?>
				<div class="form-group">
					<label>Bike Name</label>
					<input type="text" name="name" class="form-control" required="" placeholder="Enter name">
				</div>

                     <div class="form-group">
					<label>Bike Number</label>
					<input type="text" name="number" class="form-control" required="" placeholder="Enter number">
				</div>

				<div class="form-group">
					<label>description</label>
					<input type="text-area" name="description" class="form-control" required=""
					placeholder="Enter description">
				</div>

				<div class="form-group">
					<label>Price</label>
					<input type="text-area" name="price" class="form-control" required=""
					placeholder="Enter price">
				</div>


				<div class="form-group">
					<input type="file" name="image" required="">
				</div>

				

           <input type="submit" name="submit" class="btn btn-success btn-block" value="submit">
				
			</form>
			</fieldset>
			<?php
	}

?>
		</div>
	</div>
</div>

		

	



