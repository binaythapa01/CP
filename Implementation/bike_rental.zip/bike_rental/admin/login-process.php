<?php
session_start();
	include 'include/dbconnect.php';
	include 'function.php'; 


if(isset($_POST['login']) && $_POST['login']=='login'){



$data= array();
$data['username']= sanitizeString($_POST['uname']);
$data['password']= sanitizeString($_POST['psw']);



if(empty($data['username'])){
	$_SESSION['error']="username must not be empty";
	header('location: login.php');

}elseif(empty($data['password'])){

	$_SESSION['error']="password must not be empty";
	header('location: login.php');
}else{
	$result = loginProcess($data);

	


	if($result){
		
		$_SESSION['user']= $data['username'];
		$_SESSION['success']= "welcome"." ".$data['username'];
		header('location: dashoard.php');
			
	}else{
		$_SESSION['error']="username/password invalid!!";
		header('location: login.php');
	}
}
}else{
	$_SESSION['error']="invalid access!!";
	header('location: login.php');
}

?>