 <?php
session_start();

?>
<html>
	<head>
	<title>SMS</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<script src="assets/js/jquery.js"></script> 
	<script src="assets/js/app.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

	</head>
	
	
	<body>
	
		<div  class="container">
			<div class="row">
				<div class="col-lg-6">
				<?php
					include 'include/notification.php';
				?>
					<fieldset>
						<legend>ADMIN LOGIN</legend>
						<form method="post" action="login-process.php" class="form form-horizontal">
							<div class="form-group">
								<label>USERNAME</label>
								<input type="text" name="uname" class="form-control">

							</div>
							
							<div class="form-group">
								<label>PASSWORD</label>
								<input type="password" name="psw" class="form-control">

							</div>
							
							<div class="form-group">
								<input type="checkbox" name="remember">
								<label>Remember-me</label>
							</div>
							
							<input type="submit" name="login" value="login" class="btn btn-success" >
												
						
						</form>
					
					</fieldset>
				
				</div>
			</div>
		
		</div>
		
	</body>

</html>