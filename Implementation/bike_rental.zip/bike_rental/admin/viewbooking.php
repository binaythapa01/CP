<?php
// session_start();
// $email=$_SESSION['email'];

include 'include/dbconnect.php';
include 'include/header.php';
include 'function.php';




?>





			<div class="container">
			<div class="row">
				<div class="col-lg-12"  id="section">
                
				<?php
					include 'include/notification.php';
				
				?>
				<h2>VIEW BOOKING</h2>
				<table class="table table-bordered table-hover">
					<thead class="thead-dark">
						<tr>
							<th>SN</th>
							<th>Email</th>
							<th>bike name</th>
							<th>bike number</th>
							<th>date</th>
							<th>days</th>
							
							
						</tr>
					</thead>
					
					<tbody>
					
					<?php

					$result= viewbooking();

					$i=1;

					
					foreach ($result as $book) {

					  
					?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $book['email']; ?></td>
							<td><?php echo $book['bike_name']; ?></td>
							<td><?php echo $book['bike_number']; ?></td>
							<td><?php echo $book['date']; ?></td>
							<td><?php echo $book['days']; ?></td>
							<!-- <td>
								<?php 
										$url1="booking-process.php?id=".$book['book_id']."&act=delete";
									
								?>
								
								<a href="<?php echo $url1 ?>" class="btn btn-danger" 
								style="border-radius:50%" onclick="confirm('do yo want to cancel?')">
								<i class="fa fa-trash"></i></a>
							
							</td> -->
						</tr>
						
					<?php
						$i++;
						}
					?>
								
					</tbody>
				
				</table>              		
				