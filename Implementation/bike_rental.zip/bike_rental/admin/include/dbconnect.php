<?php

$conn = mysqli_connect("localhost","root","") or die("Couldnot connect to database");
$db = mysqli_select_db($conn,"bikerental") or die(mysqli_error($conn));



?>