<?php 
session_start();

if(empty($_SESSION['user'])){
	$_SESSION['error']="Access Denied!!";
	header('location: login.php');
	exit;
}
 ?>



<html>
	<head>
	<title>Dashboard of admin</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<script src="assets/js/jquery.js"></script> 
	<script src="assets/js/app.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>

	</head>
	<body>
	<!-- header -->
		<div class="container-flude">
			<div class="row">
				<div class="col-lg-12 bg-primary">
					<h1>DASHBOARD-ADMIN</h1>
					<a href="logout.php" id="logout" class="btn btn-danger"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
				</div>
			</div>
		</div> 

		<!--navigation-->
				<nav class="navbar navbar-expand bg-dark" id="nav">
			<div class="container-fluid">

				<ul class="navbar-nav">
					<li class="nav-item"><a href="viewbike.php" data-target="student" class="nav-link text-white" ><span class="fa fa-fw fa-list"></span>VIEW-bike information</a></li>
					<li class="nav-item"><a href="addbike.php" data-target="vstudent" class="nav-link"><span class="fa fa-fw fa-plus"></span>ADD-bike information</a></li>
					<!-- <li class="nav-item"><a href="vservice.php" data-target="course" class="nav-link"><i><span class="fa fa-fw fa-plus"></span>ADD-SERVICES</i></a></li>
					<li class="nav-item"><a href="view.php" data-target="vcourse" class="nav-link"><i><span class="fa fa-fw fa-list"></span>VIEW-SERVICE</i></a></li>
					<li class="nav-item"><a href="uservice.php" data-target="event" class="nav-link"><i><span class="fa fa-fw fa-plus"></span>UPADTE-SERVICE</i></a></li>
					<li class="nav-item"><a href="vmessage.php" data-target="vmessage" class="nav-link"><i><span class="fa fa-fw fa-list"></span>VIEW-MESSAGE</i></a></li>
 -->					<li class="nav-item"><a href="viewbooking.php" data-target="booking" class="nav-link"><i><span class="fa fa-fw fa-list"></span>VIEW-BOOKING</i></a></li>


				</ul>

			</div>
		</nav>

		
		<div class="container">
			<div class="row">
				<div class="col-lg-8"  id="section">
				
				<!-- <?php
				include 'include/notification.php';
				
				?> -->
			
			
					
					 
					
				</div>
			</div>
		</div>


		

	</body>



</html>