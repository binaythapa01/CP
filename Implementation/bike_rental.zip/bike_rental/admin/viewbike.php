
<?php

// session_start();
include 'include/dbconnect.php';
include 'include/header.php';
include 'function.php';

?>




		<div class="container">
			<div class="row">
				<div class="col-lg-12"  id="section">
                
				<?php
					include 'include/notification.php';
				
				?>


				<h2>VIEW Bike Infomation</h2>
				<table class="table table-bordered table-hover">
					<thead class="thead-dark">
						<tr>
							<th>SN</th>
							<th>Bike Name</th>
							<th>Bike Number</th>
							<th>Description</th>
							<th>Image</th>
							<th>PRICE</th>
							<th>Action</th>
							
						</tr>
					</thead>
					
					<tbody>
					
					<?php
					$result=viewbike();
					$i=1;
					
					foreach($result as $bike_information)
					{
						
					  
					?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $bike_information['bike_name']; ?></td>
							<td><?php echo $bike_information['bike_number']; ?></td>
							<td><?php echo $bike_information['description']; ?></td>
							<td><?php echo $bike_information['price']; ?></td>
							<td><img style="height:70px" src="uploads/<?php echo $bike_information['image']; ?>"></td>
							<td>
								<?php 
										$url1="bikeinfo-process.php?id=".$bike_information['bike_id']."&act=delete";
										$url2="addbike.php?bike_id=".$bike_information['bike_id']."&act=edit";
									
								?>
								<a href="<?php echo $url2 ?>" class="btn btn-success" style="border-radius:50%"><i class="fa fa-pencil"></i></a>
								<a href="<?php echo $url1 ?>" class="btn btn-danger" style="border-radius:50%" onclick="confirm('do yo want to delete?')"><i class="fa fa-trash"></i></a>

								
							
							</td>
						</tr>
						
					<?php
						$i++;
						}
					?>
					
					
						
						
						
					</tbody>
				
				</table>
			
                   
                    
                   		
				</div>
			</div>
		</div>



		

	</body>



