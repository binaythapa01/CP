<?php

session_start();
	include 'include/dbconnect.php';
	include 'function.php'; 



	if(isset($_GET['id']) && $_GET['act']=="delete"){
		$bike_id=$_GET['id'];
		$result = bikeinfoDelete($bike_id);
		if($result){
			$_SESSION['success']="File Deleted";
			header('location: viewbike.php');
		}
		else{
			$_SESSION['error']="File Couldnot Deleted";
			header('location: viewbike.php');
		}
	}


if(isset($_POST['submit'])&& $_POST['submit']=='submit')
{
	
	$ext = pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
		$allowed_extension= array('jpg','jpeg','png');
		
		
		if(in_array($ext,$allowed_extension)){
		$fileName = "CUR".rand(0,9999).".".$ext;
		$upload=move_uploaded_file($_FILES['image']['tmp_name'],
					"uploads/".$fileName);

		if($upload){

			
				
				$data = array();
				$data['bike_name']= sanitizeString($_POST['name']);
				$data['bike_number']= sanitizeString($_POST['number']);
				$data['description']= sanitizeString($_POST['description']);
				$data['price']= sanitizeString($_POST['price']);
			
				$data['image']= sanitizeString($fileName);
				$result = addbike($data);
				
				if($result){
					$_SESSION['success']="File uploaded";
					header('location: addbike.php');
				}else{
					$_SESSION['error']="Failed";
					header('location: addbike.php');
				}
				
				
				
				
		}else{
			
			$_SESSION['error']="File couldnot be uploaded";
			header('location: addbike.php');
			}
		}else{
		
				$_SESSION['error']="extension not allowded";
				header('location: addbike.php');
		
			}
}


if(isset($_POST['update']) && $_POST['update']=="update"){
	
		
		$ext = pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
		$allowed_extension= array('jpg','jpeg','png');
		if(in_array($ext,$allowed_extension)){
		$fileName = "CUR".rand(0,9999).".".$ext;
		$upload=move_uploaded_file($_FILES['image']['tmp_name'],
					"uploads/".$fileName);
		if($upload){
				
				$data = array();
				$data['bike_name']= sanitizeString($_POST['name']);
				$data['bike_number']= sanitizeString($_POST['number']);
				$data['description']= sanitizeString($_POST['description']);
				$data['price']= sanitizeString($_POST['price']);
				
				$data['image']= sanitizeString($fileName);
				$data['bike_id']=sanitizeString($_POST['bike_id']);
				
				
				$result = bikeupdate($data);

				
				if($result){
					$_SESSION['success']="File uploaded";
					header('location: viewbike.php');
				}else{
					$_SESSION['error']="Failed";
					header('location: viewbike.php');
				}
				
				
				
				
		}else{
			
			$_SESSION['error']="File couldnot be uploaded";
			header('location: viewbike.php');
		}
		}else{
		
				$_SESSION['error']="extension not allowded";
				header('location: viewbike.php');
		
			}
		
		
	}





 ?>