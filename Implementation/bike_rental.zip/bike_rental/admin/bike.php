<?php 

public /**
 * 
 */
class bike extends AnotherClass
{
	
	
	function sanitizeString($data){
		global $conn;
		return mysqli_real_escape_string($conn,$data);

}

function addbike($data){
   			
   			global $conn;


   			$sql ="insert into   bike_information

   					set
   					bike_name='".$data['bike_name']."',
   					bike_number='".$data['bike_number']."',
   					description='".$data['description']."',
   					image='".$data['image']."'

   			";

   			$query =mysqli_query($conn,$sql);
   			if($query){
   				return true;

   			}
   			else{
   				return false;
   			}

}

function viewbike()
   {
      global $conn;

       
      $sql= "select * from bike_information order by bike_id desc";


         $query=mysqli_query($conn,$sql);

        

      $count=mysqli_num_rows($query);


   
   if($count!=0){
      $data=array();
      while($row=mysqli_fetch_assoc($query)){
         $data[]=$row;
      }  
      return $data;
      
   
   }else{
      return false;
   }

}



function bikeinfoDelete($bike_id){
$bike_id=$bike_id;
   global $conn;
   $sql="delete from  bike_information where bike_id=$bike_id";
   $query=mysqli_query($conn,$sql);
   if($query){
      return true;
   }else{
      return false;
   }

}



function bikeupdate($data){
   global $conn;
   $sql = " update  bike_information 
          set
          bike_name ='".$data['bike_name']."',
          bike_number ='".$data['bike_number']."',
          description = '".$data['description']."',
          
          image = '".$data['image']."'
          where bike_id='".$data['bike_id']."'";

 
    $query = mysqli_query($conn,$sql);

   if($query){
      return true;
   }else{
      return false;
   }

}

function updatebike($bike_id){
   
   global $conn;
   $sql= "select * from bike_information where bike_id=$bike_id";

   
   $query=mysqli_query($conn,$sql);
   
   
   $count=mysqli_num_rows($query);
   
   if($count!=0){
      $data=array();
      while($row=mysqli_fetch_assoc($query)){
         $data[]=$row;
      }
      return $data;
      
   
   }else{
      return false;
   }
}

}


 ?>