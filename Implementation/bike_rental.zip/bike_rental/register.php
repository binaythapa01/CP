


<!DOCTYPE html>
<html>
<head>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  
    <script src="js/jquery-3.3.1.min.js"></script> 
	<script src="js/bootstrap.min.js"></script>
	
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<title>REGESTER FORM</title>
</head>
<body>

<?php
					include 'reg-processing.php';
					include 'include/notification.php';
					// header('location: register.php');
				?>


	<div  class="container">
			<div class="row">
				<div class="col-lg-6">
				
					<fieldset>
						<!-- <?php print_r($_SESSION); ?> -->

						<legend>USER REGESTER</legend>
						<form method="post" action="reg-processing.php" class="form form-horizontal">

							<div class="form-group">

								<label>First name</label>
								<input type="text" name="firstname" class="form-control">

							</div>
							<div class="form-group">

								<label>last name</label>
								<input type="text" name="lastname" class="form-control">

							</div>

							<div class="form-group">

								<label>Email</label>
								<input type="text" name="email" class="form-control">

							</div>
							
							<div class="form-group">
								<label>PASSWORD</label>
								<input type="password" name="password" class="form-control">

							</div>
							
							

							
							<input type="submit" name="signin" value="signin" class="btn btn-success" >
													
						</form>
					
					</fieldset>
				
				</div>
			</div>
		
		</div>


</body>
</html>